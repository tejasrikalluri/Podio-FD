function handleError(e) {
    if (e.status === 401 || e.status === 403 || e.status === 502) {
        notifyMsg("<span>Invalid Credentials were given.</span>");
    } else {
        handleErrorReduceComplexity(e);
    }
}

function handleErrorReduceComplexity(e) {
    if (e.status === 429) {
        notifyMsg("<span>Too many requests were made, please try after sometime.</span>");
    } else if (e.status === 500) {
        notifyMsg("<span>Unexpected error occurred, please try after sometime.</span>");
    } else if (e.status === 503) {
        notifyMsg("<span>Service unavailable, please try after sometime.</span>");
    } else if (e.status === 404) {
        notifyMsg("<span>Page not found.</span>");
    } else if (e.status === 400) {
        notifyMsg("<span>Bad request.</span>");
    } else {
        notifyMsg("<span>" + e.message + "</span>");
    }
}

function notifyMsg(msg) {
    $("#errorMsg").show().html("").append(msg);
}

function closeModal(client) {
    client.instance.close();
}

function resizeApp(client) {
    let height = $('#requiredLinks').outerHeight(true);
    client.instance.resize({
        height: height + 10
    });
}